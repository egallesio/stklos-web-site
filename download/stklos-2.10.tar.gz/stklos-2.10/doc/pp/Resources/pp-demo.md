---
title: A simple file in Markdown
author: John Doe
date: 22-Jul-2023 15:31
modified: 22-Jul-2023 17:57
template: mymd
process-command: pandoc
process-args: --from=gfm --to=html
---

## A First Section

###  A Subsection

Pellentesque dapibus suscipit ligula.  Donec posuere augue in quam.
Etiam vel tortor sodales tellus ultricies commodo.  Suspendisse
potenti.  Aenean in sem ac leo mollis blandit.  Donec neque quam,
dignissim in, mollis nec, sagittis eu, wisi.

* [ ] Cum sociis natoque penatibus et magnis dis parturient montes, nascetur
  ridiculus mus.
* [x] Phasellus purus.
* [ ] Vivamus id enim.

Praesent augue.  Fusce commodo.  Vestibulum convallis, lorem a tempus
semper, dui dui euismod elit, vitae placerat urna tortor vitae lacus.
Nullam libero mauris, consequat quis, varius et, dictum id, arcu.
Mauris mollis tincidunt felis.  
