# STklos curl demos

* `imap`: show the folder hierarchy of an IMAP server.

* `cat-url`: A cat command which accept URLs as arguments. A simple use could be

    ```sh
    $ cat-url https://stklos.net/download file:///etc/issue
    ```
