# GTKlos extension / Entry and Text widget

[Table of contents](README.md)


...

