 GTKlos extension / Dialogs

[Table of contents](README.md)


...

