C/Invoke: A library for invoking C functions at runtime.

Copyright (c) 2006 by Will Weisser

See LICENSE.txt for license info.

The C/Invoke homepage is:
http://www.nongnu.org/cinvoke/

Please subscribe to the cinvoke-dev mailing list, more
information at the above URL.

To build and install the library:

$ perl configure.pl --prefix=/usr/local
$ make
$ make install

The language bindings in the bindings/ directory must be built separately.
