## Description

This directory contains test for various SRFI implemented in STklos
Unless specifically stated, all the files here have the same copyright
than the file `test-srfi.stk` (in parent directory) which include them.
