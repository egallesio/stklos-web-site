This directory contains the R7RS standard libraries defined in the Appendix A
of the document 