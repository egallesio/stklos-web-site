#include <stdio.h>
#include <stdlib.h> /* for malloc, realloc, free */
#include "gmp.h"
#include "gmp-impl.h"

const int mp_bits_per_limb = BITS_PER_MP_LIMB;
const int __gmp_0 = 0;
int __gmp_junk;
int gmp_errno = 0;


/********** assert.c **********/

/* GMP assertion failure handler. */

/*
Copyright (C) 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA.
*/



int
#if __STDC__
__gmp_assert_fail (const char *filename, int linenum,
                   const char *expr)
#else
__gmp_assert_fail (filename, linenum, expr)
char *filename;
int  linenum;
char *expr;
#endif
{
  if (filename != NULL && filename[0] != '\0')
    {
      fprintf (stderr, "%s:", filename);
      if (linenum != -1)
        fprintf (stderr, "%d: ", linenum);
    }

  fprintf (stderr, "GNU MP assertion failed: %s\n", expr);
  abort();

  /*NOTREACHED*/
  return 0;
}



/********** insert-dbl.c **********/

/* __gmp_insert_double -- convert from array of mp_limb_t to double.

Copyright (C) 1996, 1997, 1999, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


#ifdef XDEBUG
#undef _GMP_IEEE_FLOATS
#endif

#ifndef _GMP_IEEE_FLOATS
#define _GMP_IEEE_FLOATS 0
#endif

double
#if __STDC__
__gmp_scale2 (double d, int exp)
#else
__gmp_scale2 (d, exp)
     double d;
     int exp;
#endif
{
#if _GMP_IEEE_FLOATS
  {
#if defined (__alpha) && __GNUC__ == 2 && __GNUC_MINOR__ == 8
    /* Work around alpha-specific bug in GCC 2.8.x.  */
    volatile
#endif
    union ieee_double_extract x;
    x.d = d;
    exp += x.s.exp;
    x.s.exp = exp;
    if (exp >= 2047)
      {
	/* Return +-infinity */
	x.s.exp = 2047;
	x.s.manl = x.s.manh = 0;
      }
    else if (exp < 1)
      {
	x.s.exp = 1;		/* smallest exponent (biased) */
	/* Divide result by 2 until we have scaled it to the right IEEE
	   denormalized number, but stop if it becomes zero.  */
	while (exp < 1 && x.d != 0)
	  {
	    x.d *= 0.5;
	    exp++;
	  }
      }
    return x.d;
  }
#else
  {
    double factor, r;

    factor = 2.0;
    if (exp < 0)
      {
	factor = 0.5;
	exp = -exp;
      }
    r = d;
    if (exp != 0)
      {
	if ((exp & 1) != 0)
	  r *= factor;
	exp >>= 1;
	while (exp != 0)
	  {
	    factor *= factor;
	    if ((exp & 1) != 0)
	      r *= factor;
	    exp >>= 1;
	  }
      }
    return r;
  }
#endif
}



/********** memory.c **********/

/* Memory allocation routines.

Copyright (C) 1991, 1993, 1994, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */



#ifdef __NeXT__
#define static
#endif


void *	(*_mp_allocate_func) _PROTO ((size_t)) = _mp_default_allocate;
void *	(*_mp_reallocate_func) _PROTO ((void *, size_t, size_t))
     = _mp_default_reallocate;
void	(*_mp_free_func) _PROTO ((void *, size_t)) = _mp_default_free;


/* Default allocation functions.  In case of failure to allocate/reallocate
   an error message is written to stderr and the program aborts.  */

void *
#if __STDC__
_mp_default_allocate (size_t size)
#else
_mp_default_allocate (size)
     size_t size;
#endif
{
  void *ret;
#ifdef DEBUG
  size_t req_size = size;
  size += 2 * BYTES_PER_MP_LIMB;
#endif
  ret = malloc (size);
  if (ret == 0)
    {
      perror ("cannot allocate in gmp");
      abort ();
    }
  
#ifdef DEBUG
  {
    mp_ptr p = ret;
    p++;
    p[-1] = (0xdeadbeef << 31) + 0xdeafdeed;
    if (req_size % BYTES_PER_MP_LIMB == 0)
      p[req_size / BYTES_PER_MP_LIMB] = ~((0xdeadbeef << 31) + 0xdeafdeed);
    ret = p;
  }
#endif
  return ret;
}

void *
#if __STDC__
_mp_default_reallocate (void *oldptr, size_t old_size, size_t new_size)
#else
_mp_default_reallocate (oldptr, old_size, new_size)
     void *oldptr;
     size_t old_size;
     size_t new_size;
#endif
{
  void *ret;

#ifdef DEBUG
  size_t req_size = new_size;

  if (old_size != 0)
    {
      mp_ptr p = oldptr;
      if (p[-1] != (0xdeadbeef << 31) + 0xdeafdeed)
	{
	  fprintf (stderr, "gmp: (realloc) data clobbered before allocation block\n");
	  abort ();
	}
      if (old_size % BYTES_PER_MP_LIMB == 0)
	if (p[old_size / BYTES_PER_MP_LIMB] != ~((0xdeadbeef << 31) + 0xdeafdeed))
	  {
	    fprintf (stderr, "gmp: (realloc) data clobbered after allocation block\n");
	    abort ();
	  }
      oldptr = p - 1;
    }

  new_size += 2 * BYTES_PER_MP_LIMB;
#endif

  ret = realloc (oldptr, new_size);
  if (ret == 0)
    {
      perror ("cannot allocate in gmp");
      abort ();
    }

#ifdef DEBUG
  {
    mp_ptr p = ret;
    p++;
    p[-1] = (0xdeadbeef << 31) + 0xdeafdeed;
    if (req_size % BYTES_PER_MP_LIMB == 0)
      p[req_size / BYTES_PER_MP_LIMB] = ~((0xdeadbeef << 31) + 0xdeafdeed);
    ret = p;
  }
#endif
  return ret;
}

void
#if __STDC__
_mp_default_free (void *blk_ptr, size_t blk_size)
#else
_mp_default_free (blk_ptr, blk_size)
     void *blk_ptr;
     size_t blk_size;
#endif
{
#ifdef DEBUG
  {
    mp_ptr p = blk_ptr;
    if (blk_size != 0)
      {
	if (p[-1] != (0xdeadbeef << 31) + 0xdeafdeed)
	  {
	    fprintf (stderr, "gmp: (free) data clobbered before allocation block\n");
	    abort ();
	  }
	if (blk_size % BYTES_PER_MP_LIMB == 0)
	  if (p[blk_size / BYTES_PER_MP_LIMB] != ~((0xdeadbeef << 31) + 0xdeafdeed))
	    {
	      fprintf (stderr, "gmp: (free) data clobbered after allocation block\n");
	      abort ();
	    }
      }
    blk_ptr = p - 1;
  }
#endif
  free (blk_ptr);
}



/********** mp_set_fns.c **********/

/* mp_set_memory_functions -- Set the allocate, reallocate, and free functions
   for use by the mp package.

Copyright (C) 1991, 1993, 1994 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mp_set_memory_functions (void *(*alloc_func) (size_t),
			 void *(*realloc_func) (void *, size_t, size_t),
			 void (*free_func) (void *, size_t))
#else
mp_set_memory_functions (alloc_func, realloc_func, free_func)
     void *(*alloc_func) ();
     void *(*realloc_func) ();
     void (*free_func) ();
#endif
{
  if (alloc_func == 0)
    alloc_func = _mp_default_allocate;
  if (realloc_func == 0)
    realloc_func = _mp_default_reallocate;
  if (free_func == 0)
    free_func = _mp_default_free;

  _mp_allocate_func = alloc_func;
  _mp_reallocate_func = realloc_func;
  _mp_free_func = free_func;
}



