#include <stdio.h>
#include <ctype.h>
#include <string.h>

#include "gmp.h"
#include "gmp-impl.h"
#include "longlong.h"
#undef ASSERT
#define ASSERT(expr)


/********** get_d.c **********/

/* double mpz_get_d (mpz_t src) -- Return the double approximation to SRC.

Copyright (C) 1996, 1997, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */



static int
#if __STDC__
mpn_zero_p (mp_ptr p, mp_size_t n)
#else
mpn_zero_p (p, n)
     mp_ptr p;
     mp_size_t n;
#endif
{
  mp_size_t i;

  for (i = 0; i < n; i++)
    {
      if (p[i] != 0)
	return 0;
    }

  return 1;
}


double
#if __STDC__
mpz_get_d (mpz_srcptr src)
#else
mpz_get_d (src)
     mpz_srcptr src;
#endif
{
  double res;
  mp_size_t size;
  int negative;
  mp_ptr qp;
  mp_limb_t hz, lz;
  int cnt;

  size = SIZ(src);
  if (size == 0)
    return 0.0;

  negative = size < 0;
  size = ABS (size);
  qp = PTR(src);

  if (size == 1)
    {
      res = qp[size - 1];
    }
  else if (size == 2)
    {
      res = MP_BASE_AS_DOUBLE * qp[size - 1] + qp[size - 2];
    }
  else
    {
      count_leading_zeros (cnt, qp[size - 1]);

#if BITS_PER_MP_LIMB == 32
      if (cnt == 0)
	{
	  hz = qp[size - 1];
	  lz = qp[size - 2];
	}
      else
	{
	  hz = (qp[size - 1] << cnt) | (qp[size - 2] >> BITS_PER_MP_LIMB - cnt);
	  lz = (qp[size - 2] << cnt) | (qp[size - 3] >> BITS_PER_MP_LIMB - cnt);
	}
#if _GMP_IEEE_FLOATS
      /* Take bits from less significant limbs, but only if they may affect
	 the result.  */
      if ((lz & 0x7ff) == 0x400)
	{
	  if (cnt != 0)
	    lz += ((qp[size - 3] << cnt) != 0 || ! mpn_zero_p (qp, size - 3));
	  else
	    lz += (! mpn_zero_p (qp, size - 2));
	}
#endif
      res = MP_BASE_AS_DOUBLE * hz + lz;
      res = __gmp_scale2 (res, (size - 2) * BITS_PER_MP_LIMB - cnt);
#endif
#if BITS_PER_MP_LIMB == 64
      if (cnt == 0)
	hz = qp[size - 1];
      else
	hz = (qp[size - 1] << cnt) | (qp[size - 2] >> BITS_PER_MP_LIMB - cnt);
#if _GMP_IEEE_FLOATS
      if ((hz & 0x7ff) == 0x400)
	{
	  if (cnt != 0)
	    hz += ((qp[size - 2] << cnt) != 0 || ! mpn_zero_p (qp, size - 2));
	  else
	    hz += (! mpn_zero_p (qp, size - 1));
	}
#endif
      res = hz;
      res = __gmp_scale2 (res, (size - 1) * BITS_PER_MP_LIMB - cnt);
#endif
    }

  return negative ? -res : res;
}



/********** add.c **********/

/* mpz_add -- Add two integers.

Copyright (C) 1991, 1993, 1994, 1996, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */

#ifdef BERKELEY_MP
#endif

#ifndef BERKELEY_MP
void
#if __STDC__
mpz_add (mpz_ptr w, mpz_srcptr u, mpz_srcptr v)
#else
mpz_add (w, u, v)
     mpz_ptr w;
     mpz_srcptr u;
     mpz_srcptr v;
#endif
#else /* BERKELEY_MP */
void
#if __STDC__
madd (mpz_srcptr u, mpz_srcptr v, mpz_ptr w)
#else
madd (u, v, w)
     mpz_srcptr u;
     mpz_srcptr v;
     mpz_ptr w;
#endif
#endif /* BERKELEY_MP */
{
  mp_srcptr up, vp;
  mp_ptr wp;
  mp_size_t usize, vsize, wsize;
  mp_size_t abs_usize;
  mp_size_t abs_vsize;

  usize = u->_mp_size;
  vsize = v->_mp_size;
  abs_usize = ABS (usize);
  abs_vsize = ABS (vsize);

  if (abs_usize < abs_vsize)
    {
      /* Swap U and V. */
      MPZ_SRCPTR_SWAP (u, v);
      MP_SIZE_T_SWAP (usize, vsize);
      MP_SIZE_T_SWAP (abs_usize, abs_vsize);
    }

  /* True: ABS_USIZE >= ABS_VSIZE.  */

  /* If not space for w (and possible carry), increase space.  */
  wsize = abs_usize + 1;
  if (w->_mp_alloc < wsize)
    _mpz_realloc (w, wsize);

  /* These must be after realloc (u or v may be the same as w).  */
  up = u->_mp_d;
  vp = v->_mp_d;
  wp = w->_mp_d;

  if ((usize ^ vsize) < 0)
    {
      /* U and V have different sign.  Need to compare them to determine
	 which operand to subtract from which.  */

      /* This test is right since ABS_USIZE >= ABS_VSIZE.  */
      if (abs_usize != abs_vsize)
	{
	  mpn_sub (wp, up, abs_usize, vp, abs_vsize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize < 0)
	    wsize = -wsize;
	}
      else if (mpn_cmp (up, vp, abs_usize) < 0)
	{
	  mpn_sub_n (wp, vp, up, abs_usize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize >= 0)
	    wsize = -wsize;
	}
      else
	{
	  mpn_sub_n (wp, up, vp, abs_usize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize < 0)
	    wsize = -wsize;
	}
    }
  else
    {
      /* U and V have same sign.  Add them.  */
      mp_limb_t cy_limb = mpn_add (wp, up, abs_usize, vp, abs_vsize);
      wp[abs_usize] = cy_limb;
      wsize = abs_usize + cy_limb;
      if (usize < 0)
	wsize = -wsize;
    }

  w->_mp_size = wsize;
}



/********** and.c **********/

/* mpz_and -- Logical and.

Copyright (C) 1991, 1993, 1994, 1996, 1997, 2000 Free Software Foundation,
Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_and (mpz_ptr res, mpz_srcptr op1, mpz_srcptr op2)
#else
mpz_and (res, op1, op2)
     mpz_ptr res;
     mpz_srcptr op1;
     mpz_srcptr op2;
#endif
{
  mp_srcptr op1_ptr, op2_ptr;
  mp_size_t op1_size, op2_size;
  mp_ptr res_ptr;
  mp_size_t res_size;
  mp_size_t i;
  TMP_DECL (marker);

  TMP_MARK (marker);
  op1_size = op1->_mp_size;
  op2_size = op2->_mp_size;

  op1_ptr = op1->_mp_d;
  op2_ptr = op2->_mp_d;
  res_ptr = res->_mp_d;

  if (op1_size >= 0)
    {
      if (op2_size >= 0)
	{
	  res_size = MIN (op1_size, op2_size);
	  /* First loop finds the size of the result.  */
	  for (i = res_size - 1; i >= 0; i--)
	    if ((op1_ptr[i] & op2_ptr[i]) != 0)
	      break;
	  res_size = i + 1;

	  /* Handle allocation, now then we know exactly how much space is
	     needed for the result.  */
	  if (res->_mp_alloc < res_size)
	    {
	      _mpz_realloc (res, res_size);
	      op1_ptr = op1->_mp_d;
	      op2_ptr = op2->_mp_d;
	      res_ptr = res->_mp_d;
	    }

	  /* Second loop computes the real result.  */
	  for (i = res_size - 1; i >= 0; i--)
	    res_ptr[i] = op1_ptr[i] & op2_ptr[i];

	  res->_mp_size = res_size;
	  return;
	}
      else /* op2_size < 0 */
	{
	  /* Fall through to the code at the end of the function.  */
	}
    }
  else
    {
      if (op2_size < 0)
	{
	  mp_ptr opx;
	  mp_limb_t cy;
	  mp_size_t res_alloc;

	  /* Both operands are negative, so will be the result.
	     -((-OP1) & (-OP2)) = -(~(OP1 - 1) & ~(OP2 - 1)) =
	     = ~(~(OP1 - 1) & ~(OP2 - 1)) + 1 =
	     = ((OP1 - 1) | (OP2 - 1)) + 1      */

	  /* It might seem as we could end up with an (invalid) result with
	     a leading zero-limb here when one of the operands is of the
	     type 1,,0,,..,,.0.  But some analysis shows that we surely
	     would get carry into the zero-limb in this situation...  */

	  op1_size = -op1_size;
	  op2_size = -op2_size;

	  res_alloc = 1 + MAX (op1_size, op2_size);

	  opx = (mp_ptr) TMP_ALLOC (op1_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op1_ptr, op1_size, (mp_limb_t) 1);
	  op1_ptr = opx;

	  opx = (mp_ptr) TMP_ALLOC (op2_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op2_ptr, op2_size, (mp_limb_t) 1);
	  op2_ptr = opx;

	  if (res->_mp_alloc < res_alloc)
	    {
	      _mpz_realloc (res, res_alloc);
	      res_ptr = res->_mp_d;
	      /* Don't re-read OP1_PTR and OP2_PTR.  They point to
		 temporary space--never to the space RES->_mp_d used
		 to point to before reallocation.  */
	    }

	  if (op1_size >= op2_size)
	    {
	      MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size,
			op1_size - op2_size);
	      for (i = op2_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] | op2_ptr[i];
	      res_size = op1_size;
	    }
	  else
	    {
	      MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size,
			op2_size - op1_size);
	      for (i = op1_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] | op2_ptr[i];
	      res_size = op2_size;
	    }

	  cy = mpn_add_1 (res_ptr, res_ptr, res_size, (mp_limb_t) 1);
	  if (cy)
	    {
	      res_ptr[res_size] = cy;
	      res_size++;
	    }

	  res->_mp_size = -res_size;
	  TMP_FREE (marker);
	  return;
	}
      else
	{
	  /* We should compute -OP1 & OP2.  Swap OP1 and OP2 and fall
	     through to the code that handles OP1 & -OP2.  */
          MPZ_SRCPTR_SWAP (op1, op2);
          MPN_SRCPTR_SWAP (op1_ptr,op1_size, op2_ptr,op2_size);
	}

    }

  {
#if ANDNEW
    mp_size_t op2_lim;
    mp_size_t count;

    /* OP2 must be negated as with infinite precision.

       Scan from the low end for a non-zero limb.  The first non-zero
       limb is simply negated (two's complement).  Any subsequent
       limbs are one's complemented.  Of course, we don't need to
       handle more limbs than there are limbs in the other, positive
       operand as the result for those limbs is going to become zero
       anyway.  */

    /* Scan for the least significant non-zero OP2 limb, and zero the
       result meanwhile for those limb positions.  (We will surely
       find a non-zero limb, so we can write the loop with one
       termination condition only.)  */
    for (i = 0; op2_ptr[i] == 0; i++)
      res_ptr[i] = 0;
    op2_lim = i;

    op2_size = -op2_size;

    if (op1_size <= op2_size)
      {
	/* The ones-extended OP2 is >= than the zero-extended OP1.
	   RES_SIZE <= OP1_SIZE.  Find the exact size.  */
	for (i = op1_size - 1; i > op2_lim; i--)
	  if ((op1_ptr[i] & ~op2_ptr[i]) != 0)
	    break;
	res_size = i + 1;
	for (i = res_size - 1; i > op2_lim; i--)
	  res_ptr[i] = op1_ptr[i] & ~op2_ptr[i];
	res_ptr[op2_lim] = op1_ptr[op2_lim] & -op2_ptr[op2_lim];
	/* Yes, this *can* happen!  */
	MPN_NORMALIZE (res_ptr, res_size);
      }
    else
      {
	/* The ones-extended OP2 is < than the zero-extended OP1.
	   RES_SIZE == OP1_SIZE, since OP1 is normalized.  */
	res_size = op1_size;
	MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size, op1_size - op2_size);
	for (i = op2_size - 1; i > op2_lim; i--)
	  res_ptr[i] = op1_ptr[i] & ~op2_ptr[i];
	res_ptr[op2_lim] = op1_ptr[op2_lim] & -op2_ptr[op2_lim];
      }

    res->_mp_size = res_size;
#else

    /* OP1 is positive and zero-extended,
       OP2 is negative and ones-extended.
       The result will be positive.
       OP1 & -OP2 = OP1 & ~(OP2 - 1).  */

    mp_ptr opx;

    op2_size = -op2_size;
    opx = (mp_ptr) TMP_ALLOC (op2_size * BYTES_PER_MP_LIMB);
    mpn_sub_1 (opx, op2_ptr, op2_size, (mp_limb_t) 1);
    op2_ptr = opx;

    if (op1_size > op2_size)
      {
	/* The result has the same size as OP1, since OP1 is normalized
	   and longer than the ones-extended OP2.  */
	res_size = op1_size;

	/* Handle allocation, now then we know exactly how much space is
	   needed for the result.  */
	if (res->_mp_alloc < res_size)
	  {
	    _mpz_realloc (res, res_size);
	    res_ptr = res->_mp_d;
	    op1_ptr = op1->_mp_d;
	    /* Don't re-read OP2_PTR.  It points to temporary space--never
	       to the space RES->_mp_d used to point to before reallocation.  */
	  }

	MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size,
		  res_size - op2_size);
	for (i = op2_size - 1; i >= 0; i--)
	  res_ptr[i] = op1_ptr[i] & ~op2_ptr[i];

	res->_mp_size = res_size;
      }
    else
      {
	/* Find out the exact result size.  Ignore the high limbs of OP2,
	   OP1 is zero-extended and would make the result zero.  */
	for (i = op1_size - 1; i >= 0; i--)
	  if ((op1_ptr[i] & ~op2_ptr[i]) != 0)
	    break;
	res_size = i + 1;

	/* Handle allocation, now then we know exactly how much space is
	   needed for the result.  */
	if (res->_mp_alloc < res_size)
	  {
	    _mpz_realloc (res, res_size);
	    res_ptr = res->_mp_d;
	    op1_ptr = op1->_mp_d;
	    /* Don't re-read OP2_PTR.  It points to temporary space--never
	       to the space RES->_mp_d used to point to before reallocation.  */
	  }

	for (i = res_size - 1; i >= 0; i--)
	  res_ptr[i] = op1_ptr[i] & ~op2_ptr[i];

	res->_mp_size = res_size;
      }
#endif
  }
  TMP_FREE (marker);
}



/********** clear.c **********/

/* mpz_clear -- de-allocate the space occupied by the dynamic digit space of
   an integer.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_clear (mpz_ptr m)
#else
mpz_clear (m)
     mpz_ptr m;
#endif
{
  (*_mp_free_func) (m->_mp_d, m->_mp_alloc * BYTES_PER_MP_LIMB);
}



/********** cmp_si.c **********/

/* mpz_cmp_si(u,v) -- Compare an integer U with a single-word int V.
   Return positive, zero, or negative based on if U > V, U == V, or U < V.

Copyright (C) 1991, 1993, 1994, 1995, 1996, 2000 Free Software Foundation,
Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


int
#if __STDC__
_mpz_cmp_si (mpz_srcptr u, signed long int v_digit)
#else
_mpz_cmp_si (u, v_digit)
     mpz_srcptr u;
     signed long int v_digit;
#endif
{
  mp_size_t usize = u->_mp_size;
  mp_size_t vsize;
  mp_limb_t u_digit;

  vsize = 0;
  if (v_digit > 0)
    vsize = 1;
  else if (v_digit < 0)
    {
      vsize = -1;
      v_digit = -v_digit;
    }

  if (usize != vsize)
    return usize - vsize;

  if (usize == 0)
    return 0;

  u_digit = u->_mp_d[0];

  if (u_digit == (mp_limb_t) (unsigned long) v_digit)
    return 0;

  if (u_digit > (mp_limb_t) (unsigned long) v_digit)
    return usize;
  else
    return -usize;
}



/********** cmp_ui.c **********/

/* mpz_cmp_ui.c -- Compare a mpz_t a with an mp_limb_t b.  Return positive,
  zero, or negative based on if a > b, a == b, or a < b.

Copyright (C) 1991, 1993, 1994, 1995, 1996 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


int
#if __STDC__
_mpz_cmp_ui (mpz_srcptr u, unsigned long int v_digit)
#else
_mpz_cmp_ui (u, v_digit)
     mpz_srcptr u;
     unsigned long int v_digit;
#endif
{
  mp_size_t usize = u->_mp_size;

  if (usize == 0)
    return -(v_digit != 0);

  if (usize == 1)
    {
      mp_limb_t u_digit;

      u_digit = u->_mp_d[0];
      if (u_digit > v_digit)
	return 1;
      if (u_digit < v_digit)
	return -1;
      return 0;
    }

  return (usize > 0) ? 1 : -1;
}



/********** com.c **********/

/* mpz_com(mpz_ptr dst, mpz_ptr src) -- Assign the bit-complemented value of
   SRC to DST.

Copyright (C) 1991, 1993, 1994, 1996 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_com (mpz_ptr dst, mpz_srcptr src)
#else
mpz_com (dst, src)
     mpz_ptr dst;
     mpz_srcptr src;
#endif
{
  mp_size_t size = src->_mp_size;
  mp_srcptr src_ptr;
  mp_ptr dst_ptr;

  if (size >= 0)
    {
      /* As with infinite precision: one's complement, two's complement.
	 But this can be simplified using the identity -x = ~x + 1.
	 So we're going to compute (~~x) + 1 = x + 1!  */

      if (dst->_mp_alloc < size + 1)
	_mpz_realloc (dst, size + 1);

      src_ptr = src->_mp_d;
      dst_ptr = dst->_mp_d;

      if (size == 0)
	{
	  /* Special case, as mpn_add wants the first arg's size >= the
	     second arg's size.  */
	  dst_ptr[0] = 1;
	  dst->_mp_size = -1;
	  return;
	}

      {
	mp_limb_t cy;

	cy = mpn_add_1 (dst_ptr, src_ptr, size, (mp_limb_t) 1);
	if (cy)
	  {
	    dst_ptr[size] = cy;
	    size++;
	  }
      }

      /* Store a negative size, to indicate ones-extension.  */
      dst->_mp_size = -size;
    }
  else
    {
      /* As with infinite precision: two's complement, then one's complement.
	 But that can be simplified using the identity -x = ~(x - 1).
	 So we're going to compute ~~(x - 1) = x - 1!  */
      size = -size;

      if (dst->_mp_alloc < size)
	_mpz_realloc (dst, size);

      src_ptr = src->_mp_d;
      dst_ptr = dst->_mp_d;

      mpn_sub_1 (dst_ptr, src_ptr, size, (mp_limb_t) 1);
      size -= dst_ptr[size - 1] == 0;

      /* Store a positive size, to indicate zero-extension.  */
      dst->_mp_size = size;
    }
}



/********** fdiv_qr.c **********/

/* mpz_fdiv_qr -- Division rounding the quotient towards -infinity.
   The remainder gets the same sign as the denominator.

Copyright (C) 1994, 1995, 1996, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_fdiv_qr (mpz_ptr quot, mpz_ptr rem, mpz_srcptr dividend, mpz_srcptr divisor)
#else
mpz_fdiv_qr (quot, rem, dividend, divisor)
     mpz_ptr quot;
     mpz_ptr rem;
     mpz_srcptr dividend;
     mpz_srcptr divisor;
#endif
{
  mp_size_t divisor_size = divisor->_mp_size;
  mp_size_t xsize;
  mpz_t temp_divisor;		/* N.B.: lives until function returns! */
  TMP_DECL (marker);

  TMP_MARK (marker);

  /* We need the original value of the divisor after the quotient and
     remainder have been preliminary calculated.  We have to copy it to
     temporary space if it's the same variable as either QUOT or REM.  */
  if (quot == divisor || rem == divisor)
    {
      MPZ_TMP_INIT (temp_divisor, ABS (divisor_size));
      mpz_set (temp_divisor, divisor);
      divisor = temp_divisor;
    }

  xsize = dividend->_mp_size ^ divisor_size;;
  mpz_tdiv_qr (quot, rem, dividend, divisor);

  if (xsize < 0 && rem->_mp_size != 0)
    {
      mpz_sub_ui (quot, quot, 1L);
      mpz_add (rem, rem, divisor);
    }

  TMP_FREE (marker);
}



/********** fdiv_qr_ui.c **********/

/* mpz_fdiv_qr_ui -- Division rounding the quotient towards -infinity.
   The remainder gets the same sign as the denominator.

Copyright (C) 1994, 1995, 1996, 1999 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


unsigned long int
#if __STDC__
mpz_fdiv_qr_ui (mpz_ptr quot, mpz_ptr rem, mpz_srcptr dividend, unsigned long int divisor)
#else
mpz_fdiv_qr_ui (quot, rem, dividend, divisor)
     mpz_ptr quot;
     mpz_ptr rem;
     mpz_srcptr dividend;
     unsigned long int divisor;
#endif
{
  mp_size_t dividend_size;
  mp_size_t size;
  mp_ptr quot_ptr;
  mp_limb_t remainder_limb;

  if (divisor == 0)
    DIVIDE_BY_ZERO;

  dividend_size = dividend->_mp_size;
  size = ABS (dividend_size);

  if (quot->_mp_alloc < size)
    _mpz_realloc (quot, size);

  quot_ptr = quot->_mp_d;

  remainder_limb = mpn_divmod_1 (quot_ptr, dividend->_mp_d, size,
				 (mp_limb_t) divisor);

  if (remainder_limb != 0 && dividend_size < 0)
    {
      mpn_incr_u (quot_ptr, (mp_limb_t) 1);
      remainder_limb = divisor - remainder_limb;
    }

  size -= size != 0 && quot_ptr[size - 1] == 0;
  quot->_mp_size = dividend_size >= 0 ? size : -size;

  rem->_mp_d[0] = remainder_limb;
  rem->_mp_size = remainder_limb != 0;

  return remainder_limb;
}



/********** get_si.c **********/

/* mpz_get_si(integer) -- Return the least significant digit from INTEGER.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


signed long int
#if __STDC__
mpz_get_si (mpz_srcptr op)
#else
mpz_get_si (op)
     mpz_srcptr op;
#endif
{
  mp_size_t size = op->_mp_size;
  mp_limb_t low_limb = op->_mp_d[0];

  if (size > 0)
    return low_limb % ((mp_limb_t) 1 << (BITS_PER_MP_LIMB - 1));
  else if (size < 0)
    /* This convoluted expression is necessary to properly handle 0x80000000 */
    return ~((low_limb - 1) % ((mp_limb_t) 1 << (BITS_PER_MP_LIMB - 1)));
  else
    return 0;
}



/********** get_str.c **********/

/* mpz_get_str (string, base, mp_src) -- Convert the multiple precision
   number MP_SRC to a string STRING of base BASE.  If STRING is NULL
   allocate space for the result.  In any case, return a pointer to the
   result.  If STRING is not NULL, the caller must ensure enough space is
   available to store the result.

Copyright (C) 1991, 1993, 1994, 1996 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


char *
#if __STDC__
mpz_get_str (char *res_str, int base, mpz_srcptr x)
#else
mpz_get_str (res_str, base, x)
     char *res_str;
     int base;
     mpz_srcptr x;
#endif
{
  mp_ptr xp;
  mp_size_t x_size = x->_mp_size;
  unsigned char *str;
  char *return_str;
  size_t str_size;
  char *num_to_text;
  int i;
  TMP_DECL (marker);

  TMP_MARK (marker);
  if (base >= 0)
    {
      if (base == 0)
	base = 10;
      num_to_text = "0123456789abcdefghijklmnopqrstuvwxyz";
    }
  else
    {
      base = -base;
      num_to_text = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    }

  /* We allways allocate space for the string.  If the caller passed a
     NULL pointer for RES_STR, we allocate permanent space and return
     a pointer to that to the caller.  */
  str_size = ((size_t) (ABS (x_size) * BITS_PER_MP_LIMB
			* __mp_bases[base].chars_per_bit_exactly)) + 3;
  if (res_str == 0)
    {
      /* We didn't get a string from the user.  Allocate one (and return
	 a pointer to it).  */
      res_str = (char *) (*_mp_allocate_func) (str_size);
      /* Make str, the variable used for raw result from mpn_get_str,
	 point to the same string, but just after a possible minus sign.  */
      str = (unsigned char *) res_str + 1;
    }
  else
    {
      /* Use TMP_ALLOC to get temporary space, since we need a few extra bytes
	 that we can't expect to caller to supply us with.  */
      str = (unsigned char *) TMP_ALLOC (str_size);
    }

  return_str = res_str;

  if (x_size == 0)
    {
      res_str[0] = '0';
      res_str[1] = 0;
      TMP_FREE (marker);
      return res_str;
    }
  if (x_size < 0)
    {
      *res_str++ = '-';
      x_size = -x_size;
    }

  /* Move the number to convert into temporary space, since mpn_get_str
     clobbers its argument + needs one extra high limb....  */
  xp = (mp_ptr) TMP_ALLOC ((x_size + 1) * BYTES_PER_MP_LIMB);
  MPN_COPY (xp, x->_mp_d, x_size);

  str_size = mpn_get_str (str, base, xp, x_size);

  /* mpn_get_str might make some leading zeros.  Skip them.  */
  while (*str == 0)
    {
      str_size--;
      str++;
    }

  /* Translate result to printable chars and move result to RES_STR.  */
  for (i = 0; i < str_size; i++)
    res_str[i] = num_to_text[str[i]];
  res_str[str_size] = 0;

  TMP_FREE (marker);
  return return_str;
}



/********** get_ui.c **********/

/* mpz_get_ui(integer) -- Return the least significant digit from INTEGER.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


unsigned long int
#if __STDC__
mpz_get_ui (mpz_srcptr integer)
#else
mpz_get_ui (integer)
     mpz_srcptr integer;
#endif
{
  if (integer->_mp_size == 0)
    return 0;
  else
    return integer->_mp_d[0];
}



/********** init.c **********/

/* mpz_init() -- Make a new multiple precision number with value 0.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_init (mpz_ptr x)
#else
mpz_init (x)
     mpz_ptr x;
#endif
{
  x->_mp_alloc = 1;
  x->_mp_d = (mp_ptr) (*_mp_allocate_func) (BYTES_PER_MP_LIMB);
  x->_mp_size = 0;
}



/********** iset.c **********/

/* mpz_init_set (src_integer) -- Make a new multiple precision number with
   a value copied from SRC_INTEGER.

Copyright (C) 1991, 1993, 1994, 1996 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_init_set (mpz_ptr w, mpz_srcptr u)
#else
mpz_init_set (w, u)
     mpz_ptr w;
     mpz_srcptr u;
#endif
{
  mp_ptr wp, up;
  mp_size_t usize, size;

  usize = u->_mp_size;
  size = ABS (usize);

  w->_mp_alloc = MAX (size, 1);
  w->_mp_d = (mp_ptr) (*_mp_allocate_func) (w->_mp_alloc * BYTES_PER_MP_LIMB);

  wp = w->_mp_d;
  up = u->_mp_d;

  MPN_COPY (wp, up, size);
  w->_mp_size = usize;
}



/********** iset_si.c **********/

/* mpz_init_set_si(val) -- Make a new multiple precision number with
   value val.

Copyright (C) 1991, 1993, 1994, 1995, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_init_set_si (mpz_ptr x, signed long int val)
#else
mpz_init_set_si (x, val)
     mpz_ptr x;
     signed long int val;
#endif
{
  x->_mp_alloc = 1;
  x->_mp_d = (mp_ptr) (*_mp_allocate_func) (BYTES_PER_MP_LIMB);
  if (val > 0)
    {
      x->_mp_d[0] = val;
      x->_mp_size = 1;
    }
  else if (val < 0)
    {
      x->_mp_d[0] = (unsigned long) -val;
      x->_mp_size = -1;
    }
  else
    x->_mp_size = 0;
}



/********** iset_str.c **********/

/* mpz_init_set_str(string, base) -- Convert the \0-terminated string
   STRING in base BASE to a multiple precision integer.  Return a MP_INT
   structure representing the integer.  Allow white space in the
   string.  If BASE == 0 determine the base in the C standard way,
   i.e.  0xhh...h means base 16, 0oo...o means base 8, otherwise
   assume base 10.

Copyright (C) 1991, 1993, 1994, 1995, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


int
#if __STDC__
mpz_init_set_str (mpz_ptr x, const char *str, int base)
#else
mpz_init_set_str (x, str, base)
     mpz_ptr x;
     const char *str;
     int base;
#endif
{
  x->_mp_alloc = 1;
  x->_mp_d = (mp_ptr) (*_mp_allocate_func) (BYTES_PER_MP_LIMB);

  /* if str has no digits mpz_set_str leaves x->_mp_size unset */
  x->_mp_size = 0;

  return mpz_set_str (x, str, base);
}



/********** iset_ui.c **********/

/* mpz_init_set_ui(val) -- Make a new multiple precision number with
   value val.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_init_set_ui (mpz_ptr x, unsigned long int val)
#else
mpz_init_set_ui (x, val)
     mpz_ptr x;
     unsigned long int val;
#endif
{
  x->_mp_alloc = 1;
  x->_mp_d = (mp_ptr) (*_mp_allocate_func) (BYTES_PER_MP_LIMB);
  x->_mp_d[0] = val;
  x->_mp_size = val != 0;
}



/********** ior.c **********/

/* mpz_ior -- Logical inclusive or.

Copyright (C) 1991, 1993, 1994, 1996, 1997, 2000 Free Software Foundation,
Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_ior (mpz_ptr res, mpz_srcptr op1, mpz_srcptr op2)
#else
mpz_ior (res, op1, op2)
     mpz_ptr res;
     mpz_srcptr op1;
     mpz_srcptr op2;
#endif
{
  mp_srcptr op1_ptr, op2_ptr;
  mp_size_t op1_size, op2_size;
  mp_ptr res_ptr;
  mp_size_t res_size;
  mp_size_t i;
  TMP_DECL (marker);

  TMP_MARK (marker);
  op1_size = op1->_mp_size;
  op2_size = op2->_mp_size;

  op1_ptr = op1->_mp_d;
  op2_ptr = op2->_mp_d;
  res_ptr = res->_mp_d;

  if (op1_size >= 0)
    {
      if (op2_size >= 0)
	{
	  if (op1_size >= op2_size)
	    {
	      if (res->_mp_alloc < op1_size)
		{
		  _mpz_realloc (res, op1_size);
		  op1_ptr = op1->_mp_d;
		  op2_ptr = op2->_mp_d;
		  res_ptr = res->_mp_d;
		}

	      if (res_ptr != op1_ptr)
		MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size,
			  op1_size - op2_size);
	      for (i = op2_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] | op2_ptr[i];
	      res_size = op1_size;
	    }
	  else
	    {
	      if (res->_mp_alloc < op2_size)
		{
		  _mpz_realloc (res, op2_size);
		  op1_ptr = op1->_mp_d;
		  op2_ptr = op2->_mp_d;
		  res_ptr = res->_mp_d;
		}

	      if (res_ptr != op2_ptr)
		MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size,
			  op2_size - op1_size);
	      for (i = op1_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] | op2_ptr[i];
	      res_size = op2_size;
	    }

	  res->_mp_size = res_size;
	  return;
	}
      else /* op2_size < 0 */
	{
	  /* Fall through to the code at the end of the function.  */
	}
    }
  else
    {
      if (op2_size < 0)
	{
	  mp_ptr opx;
	  mp_limb_t cy;

	  /* Both operands are negative, so will be the result.
	     -((-OP1) | (-OP2)) = -(~(OP1 - 1) | ~(OP2 - 1)) =
	     = ~(~(OP1 - 1) | ~(OP2 - 1)) + 1 =
	     = ((OP1 - 1) & (OP2 - 1)) + 1      */

	  op1_size = -op1_size;
	  op2_size = -op2_size;

	  res_size = MIN (op1_size, op2_size);

	  /* Possible optimization: Decrease mpn_sub precision,
	     as we won't use the entire res of both.  */
	  opx = (mp_ptr) TMP_ALLOC (res_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op1_ptr, res_size, (mp_limb_t) 1);
	  op1_ptr = opx;

	  opx = (mp_ptr) TMP_ALLOC (res_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op2_ptr, res_size, (mp_limb_t) 1);
	  op2_ptr = opx;

	  if (res->_mp_alloc < res_size)
	    {
	      _mpz_realloc (res, res_size);
	      res_ptr = res->_mp_d;
	      /* Don't re-read OP1_PTR and OP2_PTR.  They point to
		 temporary space--never to the space RES->_mp_d used
		 to point to before reallocation.  */
	    }

	  /* First loop finds the size of the result.  */
	  for (i = res_size - 1; i >= 0; i--)
	    if ((op1_ptr[i] & op2_ptr[i]) != 0)
	      break;
	  res_size = i + 1;

	  if (res_size != 0)
	    {
	      /* Second loop computes the real result.  */
	      for (i = res_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] & op2_ptr[i];

	      cy = mpn_add_1 (res_ptr, res_ptr, res_size, (mp_limb_t) 1);
	      if (cy)
		{
		  res_ptr[res_size] = cy;
		  res_size++;
		}
	    }
	  else
	    {
	      res_ptr[0] = 1;
	      res_size = 1;
	    }

	  res->_mp_size = -res_size;
	  TMP_FREE (marker);
	  return;
	}
      else
	{
	  /* We should compute -OP1 | OP2.  Swap OP1 and OP2 and fall
	     through to the code that handles OP1 | -OP2.  */
          MPZ_SRCPTR_SWAP (op1, op2);
          MPN_SRCPTR_SWAP (op1_ptr,op1_size, op2_ptr,op2_size);
	}
    }

  {
    mp_ptr opx;
    mp_limb_t cy;
    mp_size_t res_alloc;
    mp_size_t count;

    /* Operand 2 negative, so will be the result.
       -(OP1 | (-OP2)) = -(OP1 | ~(OP2 - 1)) =
       = ~(OP1 | ~(OP2 - 1)) + 1 =
       = (~OP1 & (OP2 - 1)) + 1      */

    op2_size = -op2_size;

    res_alloc = op2_size;

    opx = (mp_ptr) TMP_ALLOC (op2_size * BYTES_PER_MP_LIMB);
    mpn_sub_1 (opx, op2_ptr, op2_size, (mp_limb_t) 1);
    op2_ptr = opx;
    op2_size -= op2_ptr[op2_size - 1] == 0;

    if (res->_mp_alloc < res_alloc)
      {
	_mpz_realloc (res, res_alloc);
	op1_ptr = op1->_mp_d;
	res_ptr = res->_mp_d;
	/* Don't re-read OP2_PTR.  It points to temporary space--never
	   to the space RES->_mp_d used to point to before reallocation.  */
      }

    if (op1_size >= op2_size)
      {
	/* We can just ignore the part of OP1 that stretches above OP2,
	   because the result limbs are zero there.  */

	/* First loop finds the size of the result.  */
	for (i = op2_size - 1; i >= 0; i--)
	  if ((~op1_ptr[i] & op2_ptr[i]) != 0)
	    break;
	res_size = i + 1;
	count = res_size;
      }
    else
      {
	res_size = op2_size;

	/* Copy the part of OP2 that stretches above OP1, to RES.  */
	MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size, op2_size - op1_size);
	count = op1_size;
      }

    if (res_size != 0)
      {
	/* Second loop computes the real result.  */
	for (i = count - 1; i >= 0; i--)
	  res_ptr[i] = ~op1_ptr[i] & op2_ptr[i];

	cy = mpn_add_1 (res_ptr, res_ptr, res_size, (mp_limb_t) 1);
	if (cy)
	  {
	    res_ptr[res_size] = cy;
	    res_size++;
	  }
      }
    else
      {
	res_ptr[0] = 1;
	res_size = 1;
      }

    res->_mp_size = -res_size;
  }
  TMP_FREE (marker);
}



/********** mul.c **********/

/* mpz_mul -- Multiply two integers.

Copyright (C) 1991, 1993, 1994, 1996, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */

#ifdef BERKELEY_MP
#endif

#ifndef BERKELEY_MP
void
#if __STDC__
mpz_mul (mpz_ptr w, mpz_srcptr u, mpz_srcptr v)
#else
mpz_mul (w, u, v)
     mpz_ptr w;
     mpz_srcptr u;
     mpz_srcptr v;
#endif
#else /* BERKELEY_MP */
void
#if __STDC__
mult (mpz_srcptr u, mpz_srcptr v, mpz_ptr w)
#else
mult (u, v, w)
     mpz_srcptr u;
     mpz_srcptr v;
     mpz_ptr w;
#endif
#endif /* BERKELEY_MP */
{
  mp_size_t usize = u->_mp_size;
  mp_size_t vsize = v->_mp_size;
  mp_size_t wsize;
  mp_size_t sign_product;
  mp_ptr up, vp;
  mp_ptr wp;
  mp_ptr free_me = NULL;
  size_t free_me_size;
  mp_limb_t cy_limb;
  TMP_DECL (marker);

  TMP_MARK (marker);
  sign_product = usize ^ vsize;
  usize = ABS (usize);
  vsize = ABS (vsize);

  if (usize < vsize)
    {
      /* Swap U and V.  */
      {const __mpz_struct *t = u; u = v; v = t;}
      {mp_size_t t = usize; usize = vsize; vsize = t;}
    }

  up = u->_mp_d;
  vp = v->_mp_d;
  wp = w->_mp_d;

  /* Ensure W has space enough to store the result.  */
  wsize = usize + vsize;
  if (w->_mp_alloc < wsize)
    {
      if (wp == up || wp == vp)
	{
	  free_me = wp;
	  free_me_size = w->_mp_alloc;
	}
      else
	(*_mp_free_func) (wp, w->_mp_alloc * BYTES_PER_MP_LIMB);

      w->_mp_alloc = wsize;
      wp = (mp_ptr) (*_mp_allocate_func) (wsize * BYTES_PER_MP_LIMB);
      w->_mp_d = wp;
    }
  else
    {
      /* Make U and V not overlap with W.  */
      if (wp == up)
	{
	  /* W and U are identical.  Allocate temporary space for U.  */
	  up = (mp_ptr) TMP_ALLOC (usize * BYTES_PER_MP_LIMB);
	  /* Is V identical too?  Keep it identical with U.  */
	  if (wp == vp)
	    vp = up;
	  /* Copy to the temporary space.  */
	  MPN_COPY (up, wp, usize);
	}
      else if (wp == vp)
	{
	  /* W and V are identical.  Allocate temporary space for V.  */
	  vp = (mp_ptr) TMP_ALLOC (vsize * BYTES_PER_MP_LIMB);
	  /* Copy to the temporary space.  */
	  MPN_COPY (vp, wp, vsize);
	}
    }

  if (vsize == 0)
    {
      wsize = 0;
    }
  else
    {
      cy_limb = mpn_mul (wp, up, usize, vp, vsize);
      wsize = usize + vsize;
      wsize -= cy_limb == 0;
    }

  w->_mp_size = sign_product < 0 ? -wsize : wsize;
  if (free_me != NULL)
    (*_mp_free_func) (free_me, free_me_size * BYTES_PER_MP_LIMB);
  TMP_FREE (marker);
}



/********** neg.c **********/

/* mpz_neg(mpz_ptr dst, mpz_ptr src) -- Assign the negated value of SRC to DST.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_neg (mpz_ptr w, mpz_srcptr u)
#else
mpz_neg (w, u)
     mpz_ptr w;
     mpz_srcptr u;
#endif
{
  mp_ptr wp, up;
  mp_size_t usize, size;

  usize = u->_mp_size;

  if (u != w)
    {
      size = ABS (usize);

      if (w->_mp_alloc < size)
	_mpz_realloc (w, size);

      wp = w->_mp_d;
      up = u->_mp_d;

      MPN_COPY (wp, up, size);
    }

  w->_mp_size = -usize;
}



/********** realloc.c **********/

/* _mpz_realloc -- make the mpz_t have NEW_SIZE digits allocated.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void *
#if __STDC__
_mpz_realloc (mpz_ptr m, mp_size_t new_size)
#else
_mpz_realloc (m, new_size)
     mpz_ptr m;
     mp_size_t new_size;
#endif
{
  /* Never allocate zero space. */
  if (new_size == 0)
    new_size = 1;

  m->_mp_d = (mp_ptr) (*_mp_reallocate_func) (m->_mp_d,
					      m->_mp_alloc * BYTES_PER_MP_LIMB,
					      new_size * BYTES_PER_MP_LIMB);
  m->_mp_alloc = new_size;

#if 0
  /* This might break some code that reads the size field after
     reallocation, in the case the reallocated destination and a
     source argument are identical.  */
  if (ABS (m->_mp_size) > new_size)
    m->_mp_size = 0;
#endif

  return (void *) m->_mp_d;
}



/********** set.c **********/

/* mpz_set (dest_integer, src_integer) -- Assign DEST_INTEGER from SRC_INTEGER.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_set (mpz_ptr w, mpz_srcptr u)
#else
mpz_set (w, u)
     mpz_ptr w;
     mpz_srcptr u;
#endif
{
  mp_ptr wp, up;
  mp_size_t usize, size;

  usize = u->_mp_size;
  size = ABS (usize);

  if (w->_mp_alloc < size)
    _mpz_realloc (w, size);

  wp = w->_mp_d;
  up = u->_mp_d;

  MPN_COPY (wp, up, size);
  w->_mp_size = usize;
}



/********** set_si.c **********/

/* mpz_set_si(integer, val) -- Assign INTEGER with a small value VAL.

Copyright (C) 1991, 1993, 1994, 1995, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_set_si (mpz_ptr dest, signed long int val)
#else
mpz_set_si (dest, val)
     mpz_ptr dest;
     signed long int val;
#endif
{
  /* We don't check if the allocation is enough, since the rest of the
     package ensures it's at least 1, which is what we need here.  */
  if (val > 0)
    {
      dest->_mp_d[0] = val;
      dest->_mp_size = 1;
    }
  else if (val < 0)
    {
      dest->_mp_d[0] = (unsigned long) -val;
      dest->_mp_size = -1;
    }
  else
    dest->_mp_size = 0;
}



/********** set_str.c **********/

/* mpz_set_str(mp_dest, string, base) -- Convert the \0-terminated
   string STRING in base BASE to multiple precision integer in
   MP_DEST.  Allow white space in the string.  If BASE == 0 determine
   the base in the C standard way, i.e.  0xhh...h means base 16,
   0oo...o means base 8, otherwise assume base 10.

Copyright (C) 1991, 1993, 1994, 1996, 1997, 1998, 2000 Free Software
Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


static int
#if __STDC__
digit_value_in_base (int c, int base)
#else
digit_value_in_base (c, base)
     int c;
     int base;
#endif
{
  int digit;

  if (isdigit (c))
    digit = c - '0';
  else if (islower (c))
    digit = c - 'a' + 10;
  else if (isupper (c))
    digit = c - 'A' + 10;
  else
    return -1;

  if (digit < base)
    return digit;
  return -1;
}

int
#if __STDC__
mpz_set_str (mpz_ptr x, const char *str, int base)
#else
mpz_set_str (x, str, base)
     mpz_ptr x;
     const char *str;
     int base;
#endif
{
  size_t str_size;
  char *s, *begs;
  size_t i;
  mp_size_t xsize;
  int c;
  int negative;
  TMP_DECL (marker);

  /* Skip whitespace.  */
  do
    c = *str++;
  while (isspace (c));

  negative = 0;
  if (c == '-')
    {
      negative = 1;
      c = *str++;
    }

  if (digit_value_in_base (c, base == 0 ? 10 : base) < 0)
    return -1;			/* error if no digits */

  /* If BASE is 0, try to find out the base by looking at the initial
     characters.  */
  if (base == 0)
    {
      base = 10;
      if (c == '0')
	{
	  base = 8;
	  c = *str++;
	  if (c == 'x' || c == 'X')
	    {
	      base = 16;
	      c = *str++;
	    }
	  else if (c == 'b' || c == 'B')
	    {
	      base = 2;
	      c = *str++;
	    }
	}
    }

  /* Skip leading zeros.  */
  while (c == '0')
    c = *str++;
  /* Make sure the string does not become empty, mpn_set_str would fail.  */
  if (c == 0)
    {
      x->_mp_size = 0;
      return 0;
    }

  TMP_MARK (marker);
  str_size = strlen (str - 1);
  s = begs = (char *) TMP_ALLOC (str_size + 1);

  /* Remove spaces from the string and convert the result from ASCII to a
     byte array.  */
  for (i = 0; i < str_size; i++)
    {
      if (!isspace (c))
	{
	  int dig = digit_value_in_base (c, base);
	  if (dig < 0)
	    {
	      TMP_FREE (marker);
	      return -1;
	    }
	  *s++ = dig;
	}
      c = *str++;
    }

  str_size = s - begs;

  xsize = (((mp_size_t) (str_size / __mp_bases[base].chars_per_bit_exactly))
	   / BITS_PER_MP_LIMB + 2);
  if (x->_mp_alloc < xsize)
    _mpz_realloc (x, xsize);

  /* Convert the byte array in base BASE to our bignum format.  */
  xsize = mpn_set_str (x->_mp_d, (unsigned char *) begs, str_size, base);
  x->_mp_size = negative ? -xsize : xsize;

  TMP_FREE (marker);
  return 0;
}



/********** set_ui.c **********/

/* mpz_set_ui(integer, val) -- Assign INTEGER with a small value VAL.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_set_ui (mpz_ptr dest, unsigned long int val)
#else
mpz_set_ui (dest, val)
     mpz_ptr dest;
     unsigned long int val;
#endif
{
  /* We don't check if the allocation is enough, since the rest of the
     package ensures it's at least 1, which is what we need here.  */
  if (val > 0)
    {
      dest->_mp_d[0] = val;
      dest->_mp_size = 1;
    }
  else
    dest->_mp_size = 0;
}



/********** sizeinbase.c **********/

/* mpz_sizeinbase(x, base) -- return an approximation to the number of
   character the integer X would have printed in base BASE.  The
   approximation is never too small.

Copyright (C) 1991, 1993, 1994, 1995 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


size_t
#if __STDC__
mpz_sizeinbase (mpz_srcptr x, int base)
#else
mpz_sizeinbase (x, base)
     mpz_srcptr x;
     int base;
#endif
{
  mp_size_t size = ABS (x->_mp_size);
  int lb_base, cnt;
  size_t totbits;

  /* Special case for X == 0.  */
  if (size == 0)
    return 1;

  /* Calculate the total number of significant bits of X.  */
  count_leading_zeros (cnt, x->_mp_d[size - 1]);
  totbits = size * BITS_PER_MP_LIMB - cnt;

  if ((base & (base - 1)) == 0)
    {
      /* Special case for powers of 2, giving exact result.  */

      count_leading_zeros (lb_base, base);
      lb_base = BITS_PER_MP_LIMB - lb_base - 1;

      return (totbits + lb_base - 1) / lb_base;
    }
  else
    return (size_t) (totbits * __mp_bases[base].chars_per_bit_exactly) + 1;
}



/********** sqrtrem.c **********/

/* mpz_sqrtrem(root,rem,x) -- Set ROOT to floor(sqrt(X)) and REM
   to the remainder, i.e. X - ROOT**2.

Copyright (C) 1991, 1993, 1994, 1996, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */

#ifdef BERKELEY_MP
#endif

#ifndef BERKELEY_MP
void
#if __STDC__
mpz_sqrtrem (mpz_ptr root, mpz_ptr rem, mpz_srcptr op)
#else
mpz_sqrtrem (root, rem, op)
     mpz_ptr root;
     mpz_ptr rem;
     mpz_srcptr op;
#endif
#else /* BERKELEY_MP */
void
#if __STDC__
msqrt (mpz_srcptr op, mpz_ptr root, mpz_ptr rem)
#else
msqrt (op, root, rem)
     mpz_srcptr op;
     mpz_ptr root;
     mpz_ptr rem;
#endif
#endif /* BERKELEY_MP */
{
  mp_size_t op_size, root_size, rem_size;
  mp_ptr root_ptr, op_ptr;
  mp_ptr free_me = NULL;
  mp_size_t free_me_size;
  TMP_DECL (marker);

  TMP_MARK (marker);
  op_size = op->_mp_size;
  if (op_size < 0)
    SQRT_OF_NEGATIVE;

  if (rem->_mp_alloc < op_size)
    _mpz_realloc (rem, op_size);

  /* The size of the root is accurate after this simple calculation.  */
  root_size = (op_size + 1) / 2;

  root_ptr = root->_mp_d;
  op_ptr = op->_mp_d;

  if (root->_mp_alloc < root_size)
    {
      if (root_ptr == op_ptr)
	{
	  free_me = root_ptr;
	  free_me_size = root->_mp_alloc;
	}
      else
	(*_mp_free_func) (root_ptr, root->_mp_alloc * BYTES_PER_MP_LIMB);

      root->_mp_alloc = root_size;
      root_ptr = (mp_ptr) (*_mp_allocate_func) (root_size * BYTES_PER_MP_LIMB);
      root->_mp_d = root_ptr;
    }
  else
    {
      /* Make OP not overlap with ROOT.  */
      if (root_ptr == op_ptr)
	{
	  /* ROOT and OP are identical.  Allocate temporary space for OP.  */
	  op_ptr = (mp_ptr) TMP_ALLOC (op_size * BYTES_PER_MP_LIMB);
	  /* Copy to the temporary space.  Hack: Avoid temporary variable
	     by using ROOT_PTR.  */
	  MPN_COPY (op_ptr, root_ptr, op_size);
	}
    }

  rem_size = mpn_sqrtrem (root_ptr, rem->_mp_d, op_ptr, op_size);

  root->_mp_size = root_size;

  /* Write remainder size last, to enable us to define this function to
     give only the square root remainder, if the user calls if with
     ROOT == REM.  */
  rem->_mp_size = rem_size;

  if (free_me != NULL)
    (*_mp_free_func) (free_me, free_me_size * BYTES_PER_MP_LIMB);
  TMP_FREE (marker);
}



/********** sub.c **********/

/* mpz_sub -- Subtract two integers.

Copyright (C) 1991, 1993, 1994, 1996, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */

#ifdef BERKELEY_MP
#endif

#ifndef BERKELEY_MP
void
#if __STDC__
mpz_sub (mpz_ptr w, mpz_srcptr u, mpz_srcptr v)
#else
mpz_sub (w, u, v)
     mpz_ptr w;
     mpz_srcptr u;
     mpz_srcptr v;
#endif
#else /* BERKELEY_MP */
void
#if __STDC__
msub (mpz_srcptr u, mpz_srcptr v, mpz_ptr w)
#else
msub (u, v, w)
     mpz_srcptr u;
     mpz_srcptr v;
     mpz_ptr w;
#endif
#endif /* BERKELEY_MP */
{
  mp_srcptr up, vp;
  mp_ptr wp;
  mp_size_t usize, vsize, wsize;
  mp_size_t abs_usize;
  mp_size_t abs_vsize;

  usize = u->_mp_size;
  vsize = -v->_mp_size;		/* The "-" makes the difference from mpz_add */
  abs_usize = ABS (usize);
  abs_vsize = ABS (vsize);

  if (abs_usize < abs_vsize)
    {
      /* Swap U and V. */
      MPZ_SRCPTR_SWAP (u, v);
      MP_SIZE_T_SWAP (usize, vsize);
      MP_SIZE_T_SWAP (abs_usize, abs_vsize);
    }

  /* True: ABS_USIZE >= ABS_VSIZE.  */

  /* If not space for w (and possible carry), increase space.  */
  wsize = abs_usize + 1;
  if (w->_mp_alloc < wsize)
    _mpz_realloc (w, wsize);

  /* These must be after realloc (u or v may be the same as w).  */
  up = u->_mp_d;
  vp = v->_mp_d;
  wp = w->_mp_d;

  if ((usize ^ vsize) < 0)
    {
      /* U and V have different sign.  Need to compare them to determine
	 which operand to subtract from which.  */

      /* This test is right since ABS_USIZE >= ABS_VSIZE.  */
      if (abs_usize != abs_vsize)
	{
	  mpn_sub (wp, up, abs_usize, vp, abs_vsize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize < 0)
	    wsize = -wsize;
	}
      else if (mpn_cmp (up, vp, abs_usize) < 0)
	{
	  mpn_sub_n (wp, vp, up, abs_usize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize >= 0)
	    wsize = -wsize;
	}
      else
	{
	  mpn_sub_n (wp, up, vp, abs_usize);
	  wsize = abs_usize;
	  MPN_NORMALIZE (wp, wsize);
	  if (usize < 0)
	    wsize = -wsize;
	}
    }
  else
    {
      /* U and V have same sign.  Add them.  */
      mp_limb_t cy_limb = mpn_add (wp, up, abs_usize, vp, abs_vsize);
      wp[abs_usize] = cy_limb;
      wsize = abs_usize + cy_limb;
      if (usize < 0)
	wsize = -wsize;
    }

  w->_mp_size = wsize;
}



/********** sub_ui.c **********/

/* mpz_sub_ui -- Subtract an unsigned one-word integer from an MP_INT.

Copyright (C) 1991, 1993, 1994, 1996, 1999 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_sub_ui (mpz_ptr w, mpz_srcptr u, unsigned long int v)
#else
mpz_sub_ui (w, u, v)
     mpz_ptr w;
     mpz_srcptr u;
     unsigned long int v;
#endif
{
  mp_srcptr up;
  mp_ptr wp;
  mp_size_t usize, wsize;
  mp_size_t abs_usize;

  usize = u->_mp_size;
  abs_usize = ABS (usize);

  /* If not space for W (and possible carry), increase space.  */
  wsize = abs_usize + 1;
  if (w->_mp_alloc < wsize)
    _mpz_realloc (w, wsize);

  /* These must be after realloc (U may be the same as W).  */
  up = u->_mp_d;
  wp = w->_mp_d;

  if (abs_usize == 0)
    {
      wp[0] = v;
      w->_mp_size = -(v != 0);
      return;
    }

  if (usize < 0)
    {
      mp_limb_t cy;
      cy = mpn_add_1 (wp, up, abs_usize, (mp_limb_t) v);
      wp[abs_usize] = cy;
      wsize = -(abs_usize + cy);
    }
  else
    {
      /* The signs are different.  Need exact comparison to determine
	 which operand to subtract from which.  */
      if (abs_usize == 1 && up[0] < v)
	{
	  wp[0] = v - up[0];
	  wsize = -1;
	}
      else
	{
	  mpn_sub_1 (wp, up, abs_usize, (mp_limb_t) v);
	  /* Size can decrease with at most one limb.  */
	  wsize = abs_usize - (wp[abs_usize - 1] == 0);
	}
    }

  w->_mp_size = wsize;
}



/********** tdiv_qr.c **********/

/* mpz_tdiv_qr(quot,rem,dividend,divisor) -- Set QUOT to DIVIDEND/DIVISOR,
   and REM to DIVIDEND mod DIVISOR.

Copyright (C) 1991, 1993, 1994, 2000 Free Software Foundation, Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */

#ifdef BERKELEY_MP
#endif


#ifndef BERKELEY_MP

void
#if __STDC__
mpz_tdiv_qr (mpz_ptr quot, mpz_ptr rem, mpz_srcptr num, mpz_srcptr den)
#else
mpz_tdiv_qr (quot, rem, num, den)
     mpz_ptr quot;
     mpz_ptr rem;
     mpz_srcptr num;
     mpz_srcptr den;
#endif

#else /* BERKELEY_MP */

void
#if __STDC__
mdiv (mpz_srcptr num, mpz_srcptr den, mpz_ptr quot, mpz_ptr rem)
#else
mdiv (num, den, quot, rem)
     mpz_srcptr num;
     mpz_srcptr den;
     mpz_ptr    quot;
     mpz_ptr    rem;
#endif

#endif /* BERKELEY_MP */
{
  mp_size_t ql;
  mp_size_t ns, ds, nl, dl;
  mp_ptr np, dp, qp, rp;
  TMP_DECL (marker);

  ns = SIZ (num);
  ds = SIZ (den);
  nl = ABS (ns);
  dl = ABS (ds);
  ql = nl - dl + 1;

  if (dl == 0)
    DIVIDE_BY_ZERO;

  MPZ_REALLOC (rem, dl);

  if (ql <= 0)
    {
      if (num != rem)
	{
	  mp_ptr np, rp;
	  np = PTR (num);
	  rp = PTR (rem);
	  MPN_COPY (rp, np, nl);
	  SIZ (rem) = SIZ (num);
	}
      /* This needs to follow the assignment to rem, in case the
	 numerator and quotient are the same.  */
      SIZ (quot) = 0;
      return;
    }

  MPZ_REALLOC (quot, ql);

  TMP_MARK (marker);
  qp = PTR (quot);
  rp = PTR (rem);
  np = PTR (num);
  dp = PTR (den);

  /* FIXME: We should think about how to handle the temporary allocation.
     Perhaps mpn_tdiv_qr should handle it, since it anyway often needs to
     allocate temp space.  */

  /* Copy denominator to temporary space if it overlaps with the quotient
     or remainder.  */
  if (dp == rp || dp == qp)
    {
      mp_ptr tp;
      tp = (mp_ptr) TMP_ALLOC (dl * BYTES_PER_MP_LIMB);
      MPN_COPY (tp, dp, dl);
      dp = tp;
    }
  /* Copy numerator to temporary space if it overlaps with the quotient or
     remainder.  */
  if (np == rp || np == qp)
    {
      mp_ptr tp;
      tp = (mp_ptr) TMP_ALLOC (nl * BYTES_PER_MP_LIMB);
      MPN_COPY (tp, np, nl);
      np = tp;
    }

  mpn_tdiv_qr (qp, rp, 0L, np, nl, dp, dl);

  ql -=  qp[ql - 1] == 0;
  MPN_NORMALIZE (rp, dl);

  SIZ (quot) = (ns ^ ds) >= 0 ? ql : -ql;
  SIZ (rem) = ns >= 0 ? dl : -dl;
  TMP_FREE (marker);
}



/********** ui_pow_ui.c **********/

/* mpz_ui_pow_ui(res, base, exp) -- Set RES to BASE**EXP.

Copyright (C) 1991, 1993, 1994, 1996, 1997, 2000 Free Software Foundation,
Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */



static void mpz_pow2 _PROTO ((mpz_ptr r, mp_limb_t blimb, unsigned long int e, mp_limb_t rl));

void
#if __STDC__
mpz_ui_pow_ui (mpz_ptr r, unsigned long int b, unsigned long int e)
#else
mpz_ui_pow_ui (r, b, e)
     mpz_ptr r;
     unsigned long int b;
     unsigned long int e;
#endif
{
  mp_limb_t blimb = b;
  mp_limb_t rl;

  if (e == 0)
    {
      /* For x^0 we return 1, even if x is 0.  */
      r->_mp_d[0] = 1;
      r->_mp_size = 1;
      return;
    }

  /* Compute b^e as (b^n)^(e div n) * b^(e mod n), where n is chosen such that
     the latter factor is the largest number small enough to fit in a limb.  */

  rl = 1;
  while (e != 0 && blimb < ((mp_limb_t) 1 << BITS_PER_MP_LIMB/2))
    {
      if ((e & 1) != 0)
	rl = rl * blimb;
      blimb = blimb * blimb;
      e = e >> 1;
    }

  /* rl is now b^(e mod n).  (I.e., the latter factor above.)  */

  if (e == 0)
    {
      r->_mp_d[0] = rl;
      r->_mp_size = rl != 0;
      return;
    }

  mpz_pow2 (r, blimb, e, rl);
}

/* Multi-precision part of expontialization code.  */
static void
#if __STDC__
mpz_pow2 (mpz_ptr r, mp_limb_t blimb, unsigned long int e, mp_limb_t rl)
#else
mpz_pow2 (r, blimb, e, rl)
     mpz_ptr r;
     mp_limb_t blimb;
     unsigned long int e;
     mp_limb_t rl;
#endif
{
  mp_ptr rp, tp;
  mp_size_t ralloc, rsize;
  int cnt, i;
  TMP_DECL (marker);

  TMP_MARK (marker);

  /* Over-estimate temporary space requirements somewhat.  */
  count_leading_zeros (cnt, blimb);
  ralloc = e - cnt * e / BITS_PER_MP_LIMB + 1;

  /* The two areas are used to alternatingly hold the input and receive the
     product for mpn_mul.  (Needed since mpn_mul_n requires that the product
     is distinct from either input operand.)  */
  rp = (mp_ptr) TMP_ALLOC (ralloc * BYTES_PER_MP_LIMB);
  tp = (mp_ptr) TMP_ALLOC (ralloc * BYTES_PER_MP_LIMB);

  rp[0] = blimb;
  rsize = 1;

  count_leading_zeros (cnt, e);
  for (i = BITS_PER_MP_LIMB - cnt - 2; i >= 0; i--)
    {
      mpn_mul_n (tp, rp, rp, rsize);
      rsize = 2 * rsize;
      rsize -= tp[rsize - 1] == 0;
      MP_PTR_SWAP (rp, tp);

      if ((e & ((mp_limb_t) 1 << i)) != 0)
	{
	  mp_limb_t cy;
	  cy = mpn_mul_1 (rp, rp, rsize, blimb);
	  rp[rsize] = cy;
	  rsize += cy != 0;
	}
    }

  /* We will need rsize or rsize+1 limbs for the result.  */
  if (r->_mp_alloc <= rsize)
    _mpz_realloc (r, rsize + 1);

  /* Multiply the two factors (in rp,rsize and rl) and put the final result
     in place.  */
  {
    mp_limb_t cy;
    cy = mpn_mul_1 (r->_mp_d, rp, rsize, rl);
    (r->_mp_d)[rsize] = cy;
    rsize += cy != 0;
  }

  r->_mp_size = rsize;
  TMP_FREE (marker);
}



/********** xor.c **********/

/* mpz_xor -- Logical xor.

Copyright (C) 1991, 1993, 1994, 1996, 1997, 2000 Free Software Foundation,
Inc.

This file is part of the GNU MP Library.

The GNU MP Library is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2.1 of the License, or (at your
option) any later version.

The GNU MP Library is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
License for more details.

You should have received a copy of the GNU Lesser General Public License
along with the GNU MP Library; see the file COPYING.LIB.  If not, write to
the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
MA 02111-1307, USA. */


void
#if __STDC__
mpz_xor (mpz_ptr res, mpz_srcptr op1, mpz_srcptr op2)
#else
mpz_xor (res, op1, op2)
     mpz_ptr res;
     mpz_srcptr op1;
     mpz_srcptr op2;
#endif
{
  mp_srcptr op1_ptr, op2_ptr;
  mp_size_t op1_size, op2_size;
  mp_ptr res_ptr;
  mp_size_t res_size, res_alloc;
  mp_size_t i;
  TMP_DECL (marker);

  TMP_MARK (marker);
  op1_size = op1->_mp_size;
  op2_size = op2->_mp_size;

  op1_ptr = op1->_mp_d;
  op2_ptr = op2->_mp_d;
  res_ptr = res->_mp_d;

  if (op1_size >= 0)
    {
      if (op2_size >= 0)
	{
	  if (op1_size >= op2_size)
	    {
	      if (res->_mp_alloc < op1_size)
		{
		  _mpz_realloc (res, op1_size);
		  op1_ptr = op1->_mp_d;
		  op2_ptr = op2->_mp_d;
		  res_ptr = res->_mp_d;
		}

	      if (res_ptr != op1_ptr)
		MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size,
			  op1_size - op2_size);
	      for (i = op2_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	      res_size = op1_size;
	    }
	  else
	    {
	      if (res->_mp_alloc < op2_size)
		{
		  _mpz_realloc (res, op2_size);
		  op1_ptr = op1->_mp_d;
		  op2_ptr = op2->_mp_d;
		  res_ptr = res->_mp_d;
		}

	      if (res_ptr != op2_ptr)
		MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size,
			  op2_size - op1_size);
	      for (i = op1_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	      res_size = op2_size;
	    }

	  MPN_NORMALIZE (res_ptr, res_size);
	  res->_mp_size = res_size;
	  return;
	}
      else /* op2_size < 0 */
	{
	  /* Fall through to the code at the end of the function.  */
	}
    }
  else
    {
      if (op2_size < 0)
	{
	  mp_ptr opx;
	  mp_limb_t cy;

	  /* Both operands are negative, the result will be positive.
	      (-OP1) ^ (-OP2) =
	     = ~(OP1 - 1) ^ ~(OP2 - 1) =
	     = (OP1 - 1) ^ (OP2 - 1)  */

	  op1_size = -op1_size;
	  op2_size = -op2_size;

	  /* Possible optimization: Decrease mpn_sub precision,
	     as we won't use the entire res of both.  */
	  opx = (mp_ptr) TMP_ALLOC (op1_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op1_ptr, op1_size, (mp_limb_t) 1);
	  op1_ptr = opx;

	  opx = (mp_ptr) TMP_ALLOC (op2_size * BYTES_PER_MP_LIMB);
	  mpn_sub_1 (opx, op2_ptr, op2_size, (mp_limb_t) 1);
	  op2_ptr = opx;

	  res_alloc = MAX (op1_size, op2_size);
	  if (res->_mp_alloc < res_alloc)
	    {
	      _mpz_realloc (res, res_alloc);
	      res_ptr = res->_mp_d;
	      /* Don't re-read OP1_PTR and OP2_PTR.  They point to
		 temporary space--never to the space RES->_mp_d used
		 to point to before reallocation.  */
	    }

	  if (op1_size > op2_size)
	    {
	      MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size,
			op1_size - op2_size);
	      for (i = op2_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	      res_size = op1_size;
	    }
	  else
	    {
	      MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size,
			op2_size - op1_size);
	      for (i = op1_size - 1; i >= 0; i--)
		res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	      res_size = op2_size;
	    }

	  MPN_NORMALIZE (res_ptr, res_size);
	  res->_mp_size = res_size;
	  TMP_FREE (marker);
	  return;
	}
      else
	{
	  /* We should compute -OP1 ^ OP2.  Swap OP1 and OP2 and fall
	     through to the code that handles OP1 ^ -OP2.  */
          MPZ_SRCPTR_SWAP (op1, op2);
          MPN_SRCPTR_SWAP (op1_ptr,op1_size, op2_ptr,op2_size);
	}
    }

  {
    mp_ptr opx;
    mp_limb_t cy;
    mp_size_t count;

    /* Operand 2 negative, so will be the result.
       -(OP1 ^ (-OP2)) = -(OP1 ^ ~(OP2 - 1)) =
       = ~(OP1 ^ ~(OP2 - 1)) + 1 =
       = (OP1 ^ (OP2 - 1)) + 1      */

    op2_size = -op2_size;

    opx = (mp_ptr) TMP_ALLOC (op2_size * BYTES_PER_MP_LIMB);
    mpn_sub_1 (opx, op2_ptr, op2_size, (mp_limb_t) 1);
    op2_ptr = opx;

    res_alloc = MAX (op1_size, op2_size) + 1;
    if (res->_mp_alloc < res_alloc)
      {
	_mpz_realloc (res, res_alloc);
	op1_ptr = op1->_mp_d;
	res_ptr = res->_mp_d;
	/* Don't re-read OP2_PTR.  It points to temporary space--never
	   to the space RES->_mp_d used to point to before reallocation.  */
      }

    if (op1_size > op2_size)
      {
	MPN_COPY (res_ptr + op2_size, op1_ptr + op2_size, op1_size - op2_size);
	for (i = op2_size - 1; i >= 0; i--)
	  res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	res_size = op1_size;
      }
    else
      {
	MPN_COPY (res_ptr + op1_size, op2_ptr + op1_size, op2_size - op1_size);
	for (i = op1_size - 1; i >= 0; i--)
	  res_ptr[i] = op1_ptr[i] ^ op2_ptr[i];
	res_size = op2_size;
      }

    cy = mpn_add_1 (res_ptr, res_ptr, res_size, (mp_limb_t) 1);
    if (cy)
      {
	res_ptr[res_size] = cy;
	res_size++;
      }

    MPN_NORMALIZE (res_ptr, res_size);
    res->_mp_size = -res_size;
    TMP_FREE (marker);
  }
}



